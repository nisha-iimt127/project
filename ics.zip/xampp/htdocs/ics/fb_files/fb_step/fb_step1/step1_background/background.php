<html>
<head>
	
</head>
<body>

<div style="position:absolute;left:0;top:0; height:13%; width:100%; z-index:-1; background:#606060">   </div>

<div style="position:absolute;left:13.5%;top:2.5%;">  <a href="../../../index.php" style="text-decoration:none; font-size:50;font-weight:900; color:#FFFFFF;"> <font face="myFbFont"> ICS </font> </a> </div> </div>

<div style="position:absolute;left:35%;top:25%; height:10%; width:7%; z-index:-1; background:#339900; box-shadow:0px 0px 10px 1px rgb(0,0,0);">   </div>
<div style="position:absolute;left:45%;top:25%; height:10%; width:7%; z-index:-1; background:#999999;box-shadow:0px 0px 10px 1px rgb(0,0,0);">   </div>
<div style="position:absolute;left:55%;top:25%; height:10%; width:7%; z-index:-1; background:#999999;box-shadow:0px 0px 10px 1px rgb(0,0,0);">   </div>
<div style="position:absolute; left:36%; top:25%;"> <h2> Step 1 </h2> </div>
<div style="position:absolute; left:46%; top:25%;"> <h2> Step 2 </h2> </div>
<div style="position:absolute; left:56%; top:25%;"> <h2> Step 3 </h2> </div>


<div style="position:absolute; left:35%; top:40%;"> <h3> Upload Your Profile Picture </h3> </div>

<div style=" position:absolute; left:16%; top:80%;">
<meter style="height:50; width:1000;" value="10" min="0" max="100"></meter>
</div>


</body>
</html>