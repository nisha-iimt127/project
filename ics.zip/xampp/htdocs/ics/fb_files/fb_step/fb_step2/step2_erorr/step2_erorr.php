<html>
<head>
</head>
<body>

<!--que erorr Designing -->
<div style="display:none;" id="que_error"> 

<!--que erorr background -->
<div style="position:absolute;left:75%;top:45.5%; height:5%; width:15%; z-index:-1; background:#FFEBE8; box-shadow:0px 0px 7px 1px rgb(175,0,0); ">   </div>
	
<!--que erorr-->
<div style="position:absolute; left:76.5%; top:46.2%; font-size:18px;">  Select Qusestion first.  </div>
</div>


<!--ans erorr Designing -->
<div id="ans_error_design_format" style="display:none">

<!--ans erorr background -->
<div style="position:absolute;left:72%;top:55.5%; height:5%; width:15%; z-index:-1; background:#FFEBE8; box-shadow:0px 0px 7px 1px rgb(175,0,0); ">   </div>
<!--ans erorr-->
</div>

<div style="position:absolute; left:73%; top:56.2%; font-size:18px; display:none;" id="erorr_4">  Use 4 charcters or more.   </div>

</body>
</html>
