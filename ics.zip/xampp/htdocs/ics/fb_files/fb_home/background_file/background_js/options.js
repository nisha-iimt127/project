	function open_option()
	{
		document.getElementById("option").style.display='block';
	}
	function close_option()
	{
		document.getElementById("option").style.display='none';
	}
	
	function head_timeline_over()
	{
		document.getElementById("head_timeline").style.textDecoration = "underline"
	}
	function head_timeline_out()
	{
		document.getElementById("head_timeline").style.textDecoration = "none"
	}
	
	function head_about_over()
	{
		document.getElementById("head_about").style.textDecoration = "underline"
	}
	function head_about_out()
	{
		document.getElementById("head_about").style.textDecoration = "none"
	}
	function head_photos_over()
	{
		document.getElementById("head_photos").style.textDecoration = "underline"
	}
	function head_photos_out()
	{
		document.getElementById("head_photos").style.textDecoration = "none"
	}
	function head_settings_over()
	{
		document.getElementById("head_settings").style.textDecoration = "underline"
	}
	function head_settings_out()
	{
		document.getElementById("head_settings").style.textDecoration = "none"
	}
	function head_logout_over()
	{
		document.getElementById("head_logout").style.textDecoration = "underline"
	}
	function head_logout_out()
	{
		document.getElementById("head_logout").style.textDecoration = "none"
	}
	function head_feedback_over()
	{
		document.getElementById("head_feedback").style.textDecoration = "underline"
	}
	function head_feedback_out()
	{
		document.getElementById("head_feedback").style.textDecoration = "none"
	}
	function left_logout_over()
	{
		document.getElementById("logout").style.textDecoration = "underline"
	}
	function left_logout_out()
	{
		document.getElementById("logout").style.textDecoration = "none"
	}
	
	
	// left side options
	
	function left_news_feed_over()
	{
		document.getElementById("news_feed").style.textDecoration = "underline"
	}
	function left_news_feed_out()
	{
		document.getElementById("news_feed").style.textDecoration = "none"
	}
	function left_timeline_over()
	{
		document.getElementById("timeline").style.textDecoration = "underline"
	}
	function left_timeline_out()
	{
		document.getElementById("timeline").style.textDecoration = "none"
	}
	function left_about_over()
	{
		document.getElementById("about").style.textDecoration = "underline"
	}
	function left_about_out()
	{
		document.getElementById("about").style.textDecoration = "none"
	}
	function left_photos_over()
	{
		document.getElementById("photos").style.textDecoration = "underline"
	}
	function left_photos_out()
	{
		document.getElementById("photos").style.textDecoration = "none"
	}
	function left_group_message_over()
	{
		document.getElementById("group_message").style.textDecoration = "underline"
	}
	function left_group_message_out()
	{
		document.getElementById("group_message").style.textDecoration = "none"
	}
	function left_settings_over()
	{
		document.getElementById("settings").style.textDecoration = "underline"
	}
	function left_settings_out()
	{
		document.getElementById("settings").style.textDecoration = "none"
	}
	